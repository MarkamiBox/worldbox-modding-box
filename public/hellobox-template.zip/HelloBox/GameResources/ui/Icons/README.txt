Put your own art in here, in the same folder shape the game uses.

  GameResources/ui/Icons/iconHelloSwift.png  ->  "ui/Icons/iconHelloSwift"

See the Sprites & resources page of the guide. You can delete this file.
