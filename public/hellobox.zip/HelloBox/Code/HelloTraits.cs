namespace HelloBox
{
    public static class HelloTraits
    {
        // The id written once. Every other file refers to HelloTraits.SWIFT, so a typo
        // becomes a compile error instead of a trait that silently does nothing.
        public const string SWIFT = "hello_swift";

        public static void Initialize()
        {
            // Never register the same id twice. The library logs an error and overwrites.
            if (AssetManager.traits.has(SWIFT)) return;

            ActorTrait swift = new ActorTrait
            {
                id = SWIFT,
                needs_to_be_explored = false,   // already discovered, no exploring needed
                path_icon = "ui/Icons/iconHelloSwift",   // your own file, see below
                group_id = "physique",              // which tab of the trait book it sits in
                rate_birth = 0,                     // 0 = never appears on its own
                can_be_given = true,                // the player can add it in the editor
                can_be_removed = true,
                can_be_cured = false
            };

            // add() registers the trait AND allocates its stat block. Both, in that order.
            AssetManager.traits.add(swift);

            swift.base_stats["speed"] = 20f;
            swift.base_stats["attack_speed"] = 10f;
            swift.base_stats["damage"] = 5;
        }
    }
}
