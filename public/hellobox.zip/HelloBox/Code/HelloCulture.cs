namespace HelloBox
{
    public static class HelloCulture
    {
        public const string DUELLISTS = "hello_duellists";

        public static void Initialize()
        {
            if (AssetManager.culture_traits.has(DUELLISTS)) return;

            CultureTrait trait = new CultureTrait
            {
                id = DUELLISTS,
                needs_to_be_explored = false,   // already discovered, no exploring needed
                group_id = "warfare",
                path_icon = "ui/Icons/iconHelloCulture",
                priority = 10,                       // higher sorts to the top of its group
                spawn_random_trait_allowed = false,  // never handed out by chance
                can_be_given = true,                 // the player can add it in the editor
                can_be_removed = true,
                rarity = Rarity.R2_Epic
            };

            AssetManager.culture_traits.add(trait);

            // Warning below: this reaches farmers as well as soldiers.
            trait.base_stats["critical_chance"] = 0.05f;
        }
    }
}
